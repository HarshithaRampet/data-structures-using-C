# DataStructures
This repository contains programs related to Data Structures and Algorithm taught by Bhavani Shankar sir. I created repository so that I can help other students.

### How to download
If you have git in your pc, use this command to download into local folder
```
git clone https://github.com/Shivaraj21/DataStructures.git
```

if don't have git in your pc, click code on right side and then download zip
![Screenshot_1](https://user-images.githubusercontent.com/94275612/184523665-3880ae6a-f36e-42ef-ac88-462f71f3fa32.jpg)



### How to contribute
If you like to contribute to this repository,
1. Fork the repo on GitHub
2. Clone the project to your pc
3. Commit changes to your own branch
4. Push your work back up to your fork
5. Submit a Pull request
